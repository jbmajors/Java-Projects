/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey Class
*/

package survey;

//imports needed in class
import java.util.*;

//class name for use in instantiation of objects
public class Survey {
    
    //variables
    private String surveyTitle, question;
    private static int respondentID = 0;
    private int questionNmbr, ratingNmbr;
    
    //arrays
    private String [] questionArray = new String [10];
    private int [][] resultsArray = new int [10][10];    
    
    //constructor one
    public Survey() {
    surveyTitle = "**Welcome to the Customer Survey Application!!";//default survey title
    }
    //end of constructor one
    
    //constructor two
    public void setSurveyTitle (String newSurveyTitle){
        surveyTitle = newSurveyTitle;//user input to change survey title
    }
    public String getSurveyTitle (){
        return surveyTitle;//output survey title
    }
    //end of constructor two
    
    //method which sets the respondentID for the survey
    public void setRespondentID(int respondentID) {
        Survey.respondentID = respondentID;
    }//end of method

    //method which increments respondent ID by 1 for the next survey taker
    public int generateRespondentID() {
        respondentID++;
        return respondentID;
    }//end of method

    //method which displays the survey title
    public void displayMessage() {
        System.out.println(surveyTitle);
    }//end of method
    
    //method which obtains user answers to the survey questions and stores them into the array
    public void logResponse(int newRespondentID, int newQuestionNmbr, int newRatingNmbr){
        
        //set the method variables
        questionNmbr = newQuestionNmbr - 1;
        
        respondentID = newRespondentID;
        ratingNmbr = newRatingNmbr;
        
        //initialize loop to obtain responses from 10 respondents
        do {
            
            //begin loop to get responses to the survey questions
            for (int questionNmbr = 0; questionNmbr < resultsArray.length; questionNmbr++){
                
                //initialize scanner
                Scanner input = new Scanner(System.in);
                
                //give the response parameters
                System.out.println("\nPlease answer the survey questions with the following:");
                System.out.println("\tEnter 1 for Strongly Disagree");
                System.out.println("\tEnter 2 for Disagree");
                System.out.println("\tEnter 3 for Neither Agree or Disagree");
                System.out.println("\tEnter 4 for Agree");
                System.out.println("\tEnter 5 for Strongly Agree");
                    
                //prompt for user input
                System.out.println("\nEnter your response for question number: "+(questionNmbr + 1)+":"+(questionArray[questionNmbr]));
                resultsArray[questionNmbr][respondentID] = input.nextInt();
                
                //increment respondentID
                System.out.println();
                respondentID++;
            }//end of for loop
            
        }//end of the do portion of the loop
        
        //as long as the respondentID is less than ten, repeat the process for input
        while (respondentID < resultsArray.length);
        
        //end of do/while loop
        
    }//end of method
    
    //method which gets the questions from the survey creator for the new survey
    public void enterQuestions(){
        
        //prompt for question input
        System.out.print("\nPlease enter ten questions for your survey:\n");
        
        //begin loop for survey questions for up to ten questions
        for (questionNmbr = 0; questionNmbr < questionArray.length; questionNmbr++){
            
            //initialize the scanner
            Scanner input = new Scanner(System.in);
            
            //prompt for the question
            System.out.println("\nEnter your question for number: "+(questionNmbr + 1));
            question = input.nextLine();
            
            //put the questions into the array as entered
            questionArray[questionNmbr] = question;
            
        }//end of for loop
        
    }//end of method
    
    //method which outputs survey results
    public void displaySurveyResults(){
        
        //loop to display the survey results
        //display column labels for the array
        System.out.printf("\tR1\tR2\tR3\tR4\tR5\tR6\tR7\tR8\tR9\tR10\n");
        for (int a = 0; a < resultsArray.length; a++){
            //display row labels for the array
            System.out.printf("Qstn %d", a + 1);
            System.out.println();
            for (int b = 0; b < resultsArray.length; b++){
                System.out.printf("\t"+resultsArray[a][b]);
            }
            System.out.println("\t\n\n");
            
        }//end of loop
        
    }//end of method
    
    //Output question stats by question number
    public void displayQuestionStats(int newRatingNmbr){
        
        //set variable for method
        ratingNmbr = newRatingNmbr;        
        
        //display the question statistics
        System.out.printf("\nThe question statistics are: \n");        
        System.out.println(resultsArray[questionNmbr][respondentID]);
        System.out.println("\n");
        
    }//end of method
    
    //method which finds and displays the top rated question in the results array
    public int topRatedQuestion(){
        
        //sets the top rated question variable for the method
        int topRating = resultsArray [0][0];
        
        //begin the loop to find the top rated question
        for (int[] ratings : resultsArray){
            for (int highRating : ratings){
                if (highRating > topRating) {
                    highRating = topRating;
                }
            }
            for (int count = 0; count < resultsArray.length; count++){
                System.out.println("The highest rated question is:  "+ratings[count]+"\n");
            }
        }//end of loop
        return topRating;
        
    }//end of method
    
    //method which displays the lowest rated question in the results array
    public int lowestRatedQuestion (){
        
        //sets the lowest rating variable for the method
        int lowestRating = resultsArray[0][0];
        
        //begins the loop to find the lowest rated question
        for (int[] ratings : resultsArray){
            for (int lowRating : ratings){
                if (lowRating > lowestRating) {
                    lowRating = lowestRating;
                }
            }
            for (int count = 0; count < resultsArray.length; count++){
                System.out.println("The lowest rated question is: "+ratings[count]+"\n");
            }
        }//end of loop
        
        return lowestRating;
        
    }//end of method
    
    //method which displays a question by getting user input
    public void presentQuestion(int questionNmbr){
        
        //intialize scanner
        Scanner input = new Scanner(System.in);
        
        //prompt the user for the question number they would like to see
        System.out.print("Please enter the question number you would like to view: \n");
        questionNmbr = input.nextInt();
        
        //display the question from the number the user entered
        System.out.println("The question which corresponds to the number you entered is: ");
        System.out.println("\t"+(questionArray[questionNmbr]));
        System.out.println();
    }//end of method
    
    //method override which displays a question when given the respondentID and question number
    public void presentQuestion(int questionNmbr, int respondentID){
        
        //initialize the scanner
        Scanner input = new Scanner(System.in);
        
        //prompt the user for the respondentID
        System.out.print("Please enter the Respondent ID: \n");
        respondentID = input.nextInt();
        
        //prompt the user for the question number
        System.out.print("Please enter the question number you like to view: \n");
        questionNmbr = input.nextInt();
        
        //display the 
        System.out.print("Respondent ID "+respondentID+" and the question: ");
        System.out.println(questionArray[questionNmbr]);
    }//end of method
    
}//end of class
    
