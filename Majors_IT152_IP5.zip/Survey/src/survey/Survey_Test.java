/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey_Test applicaiton
*/

package survey;

//imports needed in application
import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class Survey_Test {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        
        //set variables
        String surveyTitle;
        int questionNmbr = 0, newRespondentID = 0, newQuestionNmbr = 0, newRatingNmbr = 0, menuSelect = -1;
        

        //Instantiate Survey Object and assign to mySurvey
        Survey mySurvey = new Survey();
        mySurvey.displayMessage();
        System.out.println();

        //initialize the scanner for getting user input and set menuSelect variable
        Scanner input = new Scanner(System.in);

        //call method to set the new survey title
        System.out.println("\nPlease enter a new Survey Title: \n");
        surveyTitle = input.nextLine();
        mySurvey.setSurveyTitle(surveyTitle);

        //call method to display the new survey title
        mySurvey.getSurveyTitle();
        System.out.println();
        System.out.print("The new survey title is: "+surveyTitle+"\n\n");
        
        do {
            //output user menu
            System.out.println("**************************************************");
            System.out.println("*             Survey Program Menu                *");
            System.out.println("*                                                *");
            System.out.println("* Please make a selection:                       *");
            System.out.println("* 1.  Enter survey questions                     *");
            System.out.println("* 2.  Take the survey                            *");
            System.out.println("* 3.  Display the survey results                 *");
            System.out.println("* 4.  Display the survey question statistics     *");
            System.out.println("* 5.  Display the top rated question             *");
            System.out.println("* 6.  Display the lowest rated question          *");
            System.out.println("* 7.  Display a survey question by number        *");
            System.out.println("* 8.  Display a survey question by number and ID *");
            System.out.println("* 0.  Exit the program                           *");
            System.out.println("**************************************************");
            System.out.println();

           //get user menu selection
            System.out.println("Please make a selection (0 thru 8): ");
            menuSelect = input.nextInt();
            
            //invalid entry loop
            if (menuSelect > 8){
                System.out.println("That is not a valid entry!  Please try again.");
                menuSelect = input.nextInt();
            }

            //begin switch/case block for menu selection method calls
            switch (menuSelect){

                case 1:

                    //user selected menu option number 2
                    if (menuSelect == 1){

                        //call method to enter questions into the question array
                        System.out.println();
                        mySurvey.enterQuestions();
                        System.out.println();
                    }
                    break;

                case 2: 

                    //user selected menu option number 3
                    if (menuSelect == 2){

                        //call method to answer survey questions
                        System.out.println();
                        System.out.print("Your Respondent ID is: "+mySurvey.generateRespondentID()+"\n");
                        mySurvey.logResponse(newRespondentID, newQuestionNmbr, newRatingNmbr);
                        System.out.println();
                    }
                    break;

                case 3:

                    //user selected menu option number 4
                    if (menuSelect == 3){

                        //call method to display survey results
                        System.out.println();
                        mySurvey.displaySurveyResults();
                        System.out.println();

                    }
                    break;

                case 4:

                    //user selected menu option number 5
                    if (menuSelect == 4){

                        //call method to display survey question statistics
                        System.out.println();
                        mySurvey.displayQuestionStats(newRatingNmbr);
                        System.out.println();

                    }
                    break;

                case 5:

                    //user selected menu option number 6
                    if (menuSelect == 5){

                        //call method to find and display the top rated question
                        System.out.println();
                        mySurvey.topRatedQuestion();
                        System.out.println();

                    }
                    break;

                case 6:

                    //user selected menu option number 7
                    if (menuSelect == 6){

                        //call method to find and display the lowest rated question
                        System.out.println();
                        mySurvey.lowestRatedQuestion();
                        System.out.println();

                    }
                    break;

                case 7:

                    //user selected menu option number 8
                    if (menuSelect == 7){

                        //call method to prompt for and display a specific survey question number
                        System.out.println();
                        mySurvey.presentQuestion(questionNmbr);
                        System.out.println();

                    }
                    break;

                case 8:

                    //user input menu option number 9
                    if (menuSelect == 8){

                        //call method override prompting for respondent id and question number
                        System.out.println();
                        mySurvey.presentQuestion(questionNmbr, newRespondentID);
                        System.out.println();

                    }
                    break;

                //end of cases
                
            }//End of switch
            
        }//end of do
        
        //sets the parameter of the do/while loop
        while (menuSelect != 0);
        
        //allows the user to exit the program by entering zero
        if (menuSelect == 0){

            //exit the program
            System.out.println("Thank you for using the survey program!");
            System.exit(0);

        }
        
    }//end of main method

}//end of program        
