/*
 * IT151-1402A-01 Introduction to Java Programming 1
 * File name: Majors_IT151_IP1
 * Created: 14 April 2014
 * Purpose: Beginning coding for session
 */
package Majors_IT151_IP1;

import javax.swing.*;

/**
 * Basic IO Application
 *
 * @author Jeremy Majors
 */
public class Majors_IT151_IP1 {
    
    public static void main(String[] args) {
        // declare and initialize variables 
        String openingMsg, productID, productName, productCost;
        String openingMsg1, customerProductID, customerProductName, customerProductCost;
        String idOutputMsg, nameOutputMsg, costOutputMsg, outputMsg;
       
        // display opening message and system introduction
        openingMsg1 = "*** Welcome!! *** \n\n";
        openingMsg = openingMsg1;

        JOptionPane.showMessageDialog(null, openingMsg);

        // get product id
        productID = " Please enter your Product I.D.: ";
        customerProductID = JOptionPane.showInputDialog(productID);

        // get product name  
        productName = "Please enter your Product Name: ";
        customerProductName = JOptionPane.showInputDialog(productName);
        
        // get product cost
        productCost = " Please enter your Product Cost: ";
        customerProductCost = JOptionPane.showInputDialog(productCost);

        // build output strings 
        idOutputMsg = "Product ID:         \"" + customerProductID + "\"\n";
        nameOutputMsg = "Product Name:  \"" + customerProductName + "\".\n"; 
        costOutputMsg = "Product Cost:     \"" + customerProductCost + "\".\n";

        // create output string 
        outputMsg = idOutputMsg + nameOutputMsg + costOutputMsg;

// display output message 
        JOptionPane.showMessageDialog(null, outputMsg);
        System.exit(0);
    }
}
