/*
* IT151-1402A-01 Introduction to Java Programming 1
* File name: Majors_IT151_IP2
* Created: 21 April 2014
* Purpose: Predefined Class
*/

package tomatoseeds;

/**
 * Revision 1.3, 5 May 2014
 * @author Jeremy Majors
 */
public class TomatoSeeds {

    //variable declarations
        String growerName;
        String tomatoSeedName;
        double tomatoSeedPrice;
        
    //constructor initiation
    public TomatoSeeds(String name) {
        growerName = name;
    }
           
    //set grower's name
    public void setGrowerName(String name){
        growerName = name;
    }
        
    //get grower's name
    public String getGrowerName(){
        return growerName;
    }
        
    //set tomato seed name
    public void setTomatoSeedName(String name){
        tomatoSeedName = name;
    }

    //get tomato seed name
    public String getTomatoSeedName() {
        return tomatoSeedName;
    }
    
    //set tomato seed asking price
    public void setTomatoSeedPrice(double tomatoSeedPrice) {
        this.tomatoSeedPrice = tomatoSeedPrice;
    }
        
    //get tomato seed asking price
    public double getTomatoSeedPrice(){
        return tomatoSeedPrice;
        
    }
    
    public void displayMessage()
    {
    //Welcome Message
    System.out.printf("***     Welcome To     *** \n"); 
    }
       
}
