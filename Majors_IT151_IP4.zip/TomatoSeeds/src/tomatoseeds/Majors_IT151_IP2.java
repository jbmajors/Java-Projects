/*
* IT151-1402A-01 Introduction to Java Programming 1
* File name: Majors_IT151_IP2
* Created: 21 April 2014
* Purpose: Predefined Class Application
*/

package tomatoseeds;

import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class Majors_IT151_IP2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // declare and initialize variables 
        String growerName, tomatoSeedName, verificationMsg, invalidEntry, openingMsg;
	String growerNameMsg, seedNameMsg, seedPriceMsg;
	String growerNameOutMsg, seedNameOutMsg, seedPriceOutMsg;
	String nameReturn, seedNameReturn, seedPriceReturn, thankYouMsg, emptyEntryMsg;
        double tomatoSeedPrice;
        int sentinelValue, dumpOut;

        //booleans
        boolean returnYes;
        returnYes = true;
        boolean returnNo;
        returnNo = true;
        boolean notYesOrNo;
        notYesOrNo = true;
        boolean returnYes2;
        returnYes2 = true;
        boolean returnNo2;
        returnNo2 = true;
        boolean notYesOrNo2;
        notYesOrNo2 = true;
         boolean returnYes3;
        returnYes3 = true;
        boolean returnNo3;
        returnNo3 = true;
        boolean notYesOrNo3;
        notYesOrNo3 = true;

        // Message Strings
	verificationMsg = "Is the information you entered correct? Enter y or n \n";
        invalidEntry = "Invalid Entry! Please select y or n \n";
        openingMsg = "*** The Tomato Seeds Consortium !!! *** \n\n";
        growerNameMsg = "Please enter your name: \n ";
        seedNameMsg = "Please enter the name of the tomato plant seed: \n";
	seedPriceMsg = "Please enter the price you are asking for your tomato plant seed: \n";
	thankYouMsg = "Thank You \n";
	emptyEntryMsg = "You did not enter anything! \n";
         
        //intialize a scanner to read input from the command window
        Scanner input = new Scanner(System.in);
        TomatoSeeds myTomatoSeeds = new TomatoSeeds("Tomato Seeds");
        
        //Welcome Message and Get Grower's Name
        myTomatoSeeds.displayMessage();
        System.out.print(openingMsg);
	System.out.print(growerNameMsg);
        growerName = input.nextLine();
        myTomatoSeeds.setGrowerName(growerName);
        myTomatoSeeds.getGrowerName();
        System.out.println();
        growerNameOutMsg = "The name you entered was: "+growerName+"\n";
        System.out.print(growerNameOutMsg);
        System.out.print(verificationMsg);
	nameReturn = input.nextLine();
        
	// determine if the name entered is correct
        returnYes = nameReturn.equalsIgnoreCase("y");
        returnNo = nameReturn.equalsIgnoreCase("n");
        notYesOrNo = (returnYes != true) && (returnNo != true);
        
        // initialize return flag
        
        int returnFlag = 0;

        if (returnYes) {
            returnFlag = 1;
        }
        if (returnNo) {
            returnFlag = 2;
        }
        if (notYesOrNo) {
            returnFlag = 3;
        }

        // Cases to determine correct name input  
        switch (returnFlag) {
            case 1:
                System.out.print(thankYouMsg);
                break;
                
            case 2:
                int i = 1;
                while (returnNo && i <= 3){
                    System.out.println("Please re-enter your name: \n");
                    growerName = input.nextLine();
                    myTomatoSeeds.setGrowerName(growerName);
                    myTomatoSeeds.getGrowerName();
                    System.out.println();
                    growerNameOutMsg = "The name you entered was: "+growerName+"\n";
                    System.out.print(growerNameOutMsg);
                    System.out.print(verificationMsg);
                    nameReturn = input.nextLine();
                    returnYes = nameReturn.equalsIgnoreCase("y");
                    returnNo = nameReturn.equalsIgnoreCase("n");
                        if (returnYes){
                            System.out.print(thankYouMsg);
                            break;
                        }
                    if (i == 3) {
                        System.exit(0);
                    }else{
                        ++i;
                    }
                }
                break;
                
            case 3:
                if (notYesOrNo){
                    System.out.print(invalidEntry);
                    nameReturn = input.nextLine();
                    returnYes = nameReturn.equalsIgnoreCase("y");
                    returnNo = nameReturn.equalsIgnoreCase("n");
                        if (returnYes){
                            System.out.print(thankYouMsg);
                            break;
                        }
                        if (returnNo){
                            System.exit(0);
                        }
                }
            
        } //end switch
        
	System.out.print(seedNameMsg);
        tomatoSeedName = input.nextLine();
        myTomatoSeeds.setTomatoSeedName(tomatoSeedName);
        myTomatoSeeds.getTomatoSeedName();
        System.out.println();
        seedNameOutMsg = "The name you entered was: "+ tomatoSeedName +"\n";
        System.out.print(seedNameOutMsg);
        System.out.print(verificationMsg);
	seedNameReturn = input.nextLine();
        
	// determine if the seed name entered is correct
        returnYes2 = seedNameReturn.equalsIgnoreCase("y");
        returnNo2 = seedNameReturn.equalsIgnoreCase("n");
        notYesOrNo2 = (returnYes2 != true) && (returnNo2 != true);
        
        // initialize return flag
        
        int returnFlag2 = 0;

        if (returnYes2) {
            returnFlag2 = 1;
        }
        if (returnNo2) {
            returnFlag2 = 2;
        }
        if (notYesOrNo2) {
            returnFlag2 = 3;
        }

        // Cases to determine correct name input  
        switch (returnFlag2) {
            case 1:
                System.out.print(thankYouMsg);
                break;
                
            case 2:
                int j = 1;
                while (returnNo2 && j <= 3){
                    System.out.println("Please re-enter tomato plant seed name: \n");
                    tomatoSeedName = input.nextLine();
                    myTomatoSeeds.setTomatoSeedName(tomatoSeedName);
                    myTomatoSeeds.getTomatoSeedName();
                    System.out.println();
                    seedNameOutMsg = "The name you entered was: "+ tomatoSeedName +"\n";
                    System.out.print(seedNameOutMsg);
                    System.out.print(verificationMsg);
                    seedNameReturn = input.nextLine();
                    returnYes2 = seedNameReturn.equalsIgnoreCase("y");
                    returnNo2 = seedNameReturn.equalsIgnoreCase("n");
                        if (returnYes2){
                            System.out.print(thankYouMsg);
                            break;
                        }
                    if (j == 3) {
                        System.exit(0);
                    }else{
                        ++j;
                    }
                }
                break;
                
            case 3:
                if (notYesOrNo2){
                    System.out.print(invalidEntry);
                    seedNameReturn = input.nextLine();
                    returnYes2 = seedNameReturn.equalsIgnoreCase("y");
                    returnNo2 = seedNameReturn.equalsIgnoreCase("n");
                        if (returnYes2){
                            System.out.print(thankYouMsg);
                            break;
                        }
                        if (returnNo2){
                            System.exit(0);
                        }
                }
            
        } //end switch
        
                
	System.out.print(seedPriceMsg);
        tomatoSeedPrice = input.nextDouble();
        myTomatoSeeds.setTomatoSeedPrice(tomatoSeedPrice);
        myTomatoSeeds.getTomatoSeedPrice();
        System.out.println();
        sentinelValue = -1;
        while (sentinelValue != -1){
            seedPriceOutMsg = "The price you entered was: $"+ tomatoSeedPrice +"\n";
            System.out.println("If you wish to exit the program, enter -1");
            dumpOut = input.nextInt();
            
            System.out.print(verificationMsg);
            seedPriceReturn = input.nextLine();
            
            System.out.print(seedPriceOutMsg);
        
        
            // determine if the seed name entered is correct
            returnYes3 = seedPriceReturn.equalsIgnoreCase("y");
            returnNo3 = seedPriceReturn.equalsIgnoreCase("n");
            notYesOrNo3 = (returnYes3 != true) && (returnNo3 != true);
        
            // initialize return flag
        
            int returnFlag3 = 0;

            if (returnYes3) {
                returnFlag3 = 1;
            }
            if (returnNo3) {
                returnFlag3 = 2;
            }
            if (notYesOrNo3) {
                returnFlag3 = 3;
            }

            // Cases to determine correct name input  
            switch (returnFlag3) {
                case 1:
                    System.out.print(thankYouMsg);
                    break;
                
                case 2:
                int k = 1;
                    while (returnNo3 && k <= 3){
                        System.out.println("Please re-enter tomato plant seed price: \n");
                        tomatoSeedPrice = input.nextDouble();
                        myTomatoSeeds.setTomatoSeedPrice(tomatoSeedPrice);
                        myTomatoSeeds.getTomatoSeedPrice();
                        System.out.println();
                        seedPriceOutMsg = "The price you entered was: $"+ tomatoSeedPrice +"\n";
                        System.out.print(seedPriceOutMsg);
                        System.out.print(verificationMsg);
                        seedPriceReturn = input.nextLine();
                        returnYes3 = seedPriceReturn.equalsIgnoreCase("y");
                        returnNo3 = seedPriceReturn.equalsIgnoreCase("n");
                        if (returnYes3){
                            System.out.print(thankYouMsg);
                            break;
                        }
                        if (k == 3) {
                            System.exit(0);
                        }else{
                            ++k;
                        }
                    }
                    break;
                
                case 3:
                    if (notYesOrNo3){
                        System.out.print(invalidEntry);
                        seedPriceReturn = input.nextLine();
                        returnYes3 = seedPriceReturn.equalsIgnoreCase("y");
                        returnNo3 = seedPriceReturn.equalsIgnoreCase("n");
                        if (returnYes3){
                            System.out.print(thankYouMsg);
                            break;
                        }
                        if (returnNo3){
                            System.exit(0);
                        }
                    }
            
                } //end switch
            if (dumpOut == -1){
                System.exit(0);
            }
        }
    }
}