/*
 * IT151-1402A-01 Introduction to Java Programming 1
 * File name: Majors_IT151_IP2
 * Created: 21 April 2014
 * Purpose: Class Development
 */

package majors_it151_ip2;

import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class Majors_IT151_IP2 {

    public static void main(String[] args) {
        
        //intialize a scanner to read input from the command window
        Scanner input = new Scanner(System.in);
        
        //variable declarations
        String growerName;
        String tomatoName;
        double tomatoCost;
        
        //constructor initiation
        public Majors_IT151_IP2(String name) {
            growerName = name;
        }
        
        //set growers name
        public void setGrowerName(String name){
            System.out.println("Please enter your name: ");
            growerName = input.nextLine();
            System.out.println();
        }
        
        //get grower name
        public void getGrowerName(String name){
        }
        
        //get tomato name
        public void getTomatoName(String name){
            System.out.println("Please enter the tomato seed plant name: ");
            tomatoName = input.nextLine();
            System.out.println();
        }
        
        //get tomato cost
        public void getTomatoCost(){
            System.out.println("Please enter the price you are asking for the tomato seed: ");
            tomatoCost = input.nextDouble();
            System.out.println();
        }
       
    }
}    //end of application

