/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Accounts Super Class
*/

package accounts;
/**
 *
 * @author Jeremy Majors
 */
public abstract class Accounts implements Accounts_Interface {
    //Variables
    private String nameCustomer;
    private String billingAddress; 
    private String deliveryAddress;
    private String emailAddress; 
    private int accountID;

    
    //constructor with arguments
    public Accounts (String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID) { 
        
        nameCustomer = aNameCustomer;
        billingAddress = aBillingAddress;
        deliveryAddress = aDeliveryAddress;
        emailAddress = anEmailAddress;
        accountID = anAccountID;
        
    }

    //begin public methods
    
    //set the Account ID
    public void setAccountID(int anAccountID) {
        this.accountID = anAccountID;
    }

    //get the Account ID
    public int getAccountID() {
        return accountID;
    }

    //set the Customer Name
    public void setNameCustomer(String aNameCustomer) {
        this.nameCustomer = aNameCustomer;
    }

    //get the Customer Name
    public String getNameCustomer() {
        return nameCustomer;
    }
    
    //set the Customer's Billing Address
    public void setBillingAddress(String aBillingAddress) {
        this.billingAddress = aBillingAddress;
    }

    //get the Customer's Billing Address
    public String getBillingAddress() {
        return billingAddress;
    }

    //set the Customer's Delivery Address
    public void setDeliveryAddress(String aDeliveryAddress) {
        this.deliveryAddress = aDeliveryAddress;
    }

    //get the Customer's Delivery Address
    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    //set the Customer's Email Address
    public void setEmailAddress(String anEmailAddress) {
        this.emailAddress = anEmailAddress;
    }

    //get the Customer's Email Address
    public String getEmailAddress() {
        return emailAddress;
    }
    
    //Override toString method for subclass share
    @Override
    public String toString() {
       //return string with formatting for accounts variables
       return String.format( "\n%s %s \n%s %s \n%s %s \n%s %s", 
         "Account ID: ", getAccountID(),
         "Company customer's name: ", getNameCustomer(), 
         "Company billing address: ", getBillingAddress(), 
         "Company delivery address: ", getDeliveryAddress(), 
         "Company email address: ", getEmailAddress());
   }
    
    //end public methods
    
    //abstract for computeSales allowing subclasses to override
    @Override
    public abstract double computeSales();
    

}//end of super class
