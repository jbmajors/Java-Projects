/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Paper Subclass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Paper extends Accounts {
    
    //variables
    private double numberLbsPaper;
    private double pricePerPds;
    
//Constructor with arguments
public Paper(String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID,
        double numLbsPaper, double pricePerLbs){
    super(aNameCustomer, aBillingAddress, aDeliveryAddress, anEmailAddress, anAccountID);
    numberLbsPaper = numLbsPaper;
    pricePerPds = pricePerLbs;
}
    //set the number of pounds of paper
    public void setNumberLbsPaper(double numberLbsPaper) {
        this.numberLbsPaper = numberLbsPaper;
    }//end set method
    
    //get the number of pounds of paper
    public double getNumberLbsPaper(){    
        return numberLbsPaper;
    }//end get method

    //set the price per pound of paper
    public void setPricePerPds(double pricePerPds){    
        this.pricePerPds = pricePerPds;
    }//end set method
    
    //get the price per pound of paper
    public double getPricePerPds(){    
        return pricePerPds;
    }//end get method
    
    //Override computeSales super class
    @Override
    public double computeSales() {
        return (pricePerPds * numberLbsPaper);//total sales computation for paper division
    } //end override
    
    //Override toString method in super class
    @Override
    public String toString(){
        
        //return string with arguments
        return String.format( "\n%s \n%s \n%s %s \n%s $%s \n%s $%s", 
            "Paper account information: ", super.toString(), 
            "Number of pounds of paper sold: ", getNumberLbsPaper()+" lbs",
            "Price per pound of paper: ", getPricePerPds(),
            "Total purchase price for paper: ", computeSales());

    }//end override
    
}//end paper class