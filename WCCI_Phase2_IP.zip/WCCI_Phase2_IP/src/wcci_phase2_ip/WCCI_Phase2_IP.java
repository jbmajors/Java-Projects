/*
 * IT110-1302A-04 Introduction to Java Programming
 * File name: WCCI_Phase2_IP
 * Created: 20 April 2013
 * Purpose: To create a customized welcome for Worldwide Chocolate and 
 * Coffee Imports
 */
package wcci_phase2_ip;

import java.text.MessageFormat;
import javax.swing.*;

/**
 * Worldwide Chocolate and Coffee Imports (WCCI) Application
 * @author Jeremy Majors
 */
public class WCCI_Phase2_IP {   
    /**
     * Parameters
     */
    public static void main(String[] args) {
        //Declarations
        String openingMsg;
        String customerName; 
        String nameInputMsg;
        String returnOutputMsg;
        String greetingOutputMsg;
        String customerReturn;
        String outputMsg;
        String nameOutputMsg; 
        //Welcome message
        openingMsg = "Welcome to Worldwide Chocolate and Coffee Imports";
        JOptionPane.showMessageDialog(null, openingMsg);
        //Name input
        nameInputMsg = "Please enter your name:";
        customerName = JOptionPane.showInputDialog(null, nameInputMsg);
        //Customer welcome
        JOptionPane.showMessageDialog(null, MessageFormat.format("Hello,{0}!", customerName));
        //Return customer question
        JOptionPane.showConfirmDialog(null,"Are you a return customer?", "Are you a return customer?", JOptionPane.YES_NO_OPTION);
        //Add method here for directing yes or no answer
        //Return customer welcome
        returnOutputMsg = "Thank you for shopping with us again!!";
        JOptionPane.showMessageDialog(null, returnOutputMsg);
        //Add dialog for new customer greeting
        //Exit message
        greetingOutputMsg = "Thank you for visiting WCCI!";
        JOptionPane.showMessageDialog (null, greetingOutputMsg);
    }//end main
}//end class