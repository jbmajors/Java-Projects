/*
* IT151-1402A-01 Introduction to Java Programming 1
* File name: Majors_IT151_IP2
* Created: 21 April 2014
* Purpose: Predefined Class
*/

package tomatoseeds;

/**
 *
 * @author Jeremy Majors
 */
public class TomatoSeeds {

    //variable declarations
        String growerName;
        String tomatoName;
        double tomatoCost;
        
    //constructor initiation
    public TomatoSeeds(String name) {
        growerName = name;
    }
           
    //set grower's name
    public void setGrowerName(String name){
        growerName = name;
    }
        
    //get grower's name
    public String getGrowerName(){
        return growerName;
    }
        
    //set tomato seed name
    public void setTomatoName(String name){
        tomatoName = name;
    }

    //get tomato seed name
    public String getTomatoName() {
        return tomatoName;
    }
    
    //set tomato seed asking price
    public void setTomatoCost(double tomatoCost) {
        this.tomatoCost = tomatoCost;
    }
        
    //get tomato seed asking price
    public double getTomatoCost(){
        return tomatoCost;
        
    }
    
    public void displayMessage()
    {
    //Welcome Message
    System.out.printf("Welcome " + getGrowerName() + "\n "); 
    }
       
}
