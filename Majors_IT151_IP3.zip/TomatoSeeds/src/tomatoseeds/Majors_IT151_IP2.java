/*
* IT151-1402A-01 Introduction to Java Programming 1
* File name: Majors_IT151_IP2
* Created: 21 April 2014
* Purpose: Predefined Class Application
*/

package tomatoseeds;

import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class Majors_IT151_IP2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //variable declarations
        String growerName, tomatoName, correctInputMsg, correctReturn;
        double tomatoCost;
        
        //booleans
        boolean returnYes;
        returnYes = true;
        boolean returnNo;
        returnNo = true;
        boolean notYesOrNo;
        notYesOrNo = true;
        
        //intialize a scanner to read input from the command window
        Scanner input = new Scanner(System.in);
        TomatoSeeds myTomatoSeeds = new TomatoSeeds("Tomato Seeds");
        
        //Grower's Name Input
        System.out.println("Please enter your name: ");
        growerName = input.nextLine();
        myTomatoSeeds.setGrowerName(growerName);
        myTomatoSeeds.getGrowerName();
        System.out.println();
        System.out.println("The name you entered was: "+growerName+"\n\n");
        
        
        //Welcome Message Display
        myTomatoSeeds.displayMessage();
       
        //begin while loop
        while (notYesOrNo || returnNo){
   
            //Tomato Plant Seed Name Input
            System.out.println("\n\nPlease enter the tomato seed plant name: ");
            tomatoName = input.nextLine();
            myTomatoSeeds.setTomatoName(tomatoName);
            myTomatoSeeds.getTomatoName();
            System.out.println();
            System.out.println("The tomato seed plant name you entered was: "+tomatoName+"\n\n"); 
            
            System.out.println("Is this correct?  (Enter y or n)? ");
            correctReturn = input.nextLine();
            returnYes = correctReturn.equalsIgnoreCase("y");
            returnNo = correctReturn.equalsIgnoreCase("n");
            notYesOrNo = (returnYes != correctReturn.equalsIgnoreCase("y")) && (returnNo != correctReturn.equalsIgnoreCase("n"));
            
            if (returnYes){
                break;
            }
        }             
        System.out.println();
        //Tomato Plant Seed Asking Price Input
        System.out.println("Please enter the price you are asking for the tomato seed per oz - $ 0 to $4.99: ");
        tomatoCost = input.nextDouble();
        myTomatoSeeds.setTomatoCost(tomatoCost);
        myTomatoSeeds.getTomatoCost();
        
        //begin while sentinel
        while (tomatoCost != -1.00){
            
            if (tomatoCost >= 5){
                System.out.print("That is an invalid entry!\n\n");
            }//end if
            else{
                System.out.println("The price you are asking for your tomato seeds is: $"+tomatoCost+"\n\n");
                break;
            }//end else
            
        }//end while sentinel
        
    }//end main application
    
}//end main class