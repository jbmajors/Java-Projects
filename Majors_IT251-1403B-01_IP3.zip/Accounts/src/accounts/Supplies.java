/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Supplies SubClass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Supplies extends Accounts {
    
      //variables
      private double suppliesSold;
      private double booksSold;
      private double apparelSold;
      
//Constructor with arguments for supplies subclass variables    
    public Supplies (String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID, 
            double splsSold, double bksSold, double aprlSold) { 
        super(aNameCustomer, aBillingAddress, aDeliveryAddress, anEmailAddress, anAccountID);
        suppliesSold = splsSold;       
        booksSold = bksSold;
        apparelSold = aprlSold;
    
    }

    //set the amount of apparel sold
    public void setApparelSold(double aprlSold) {
        this.apparelSold = aprlSold;
    }//end set method

    //get the amount of apparel sold
    public double getApparelSold() {
        return apparelSold;
    }//end get method

    //set the amount of books sold
    public void setBooksSold(double bksSold) {
        this.booksSold = bksSold;
    }//end set method

    //get the amount of books sold
    public double getBooksSold() {
        return booksSold;
    }//end get method

    //set the amount of supplies sold
    public void setSuppliesSold(double splsSold) {
        this.suppliesSold = splsSold;
    }//end set method

    //get the amount of supplies sold
    public double getSuppliesSold() {
        return suppliesSold;
    }//end get method

    //Override computeSales method super class
    @Override
    public double computeSales(){
        return (suppliesSold + booksSold + apparelSold);
    }//end override
    
    //Override toString method in super class
    @Override
    public String toString(){
        
        //return string with arguments
        return String.format( "\n%s \n%s \n%s $%s \n%s $%s \n%s $%s \n%s $%s", 
            "Supplies account information: ", super.toString(), 
            "Number of office supplies sold: ", getSuppliesSold(),
            "Number of books sold: ", getBooksSold(),
            "Number of apparel items sold: ", getApparelSold(),
            "Total sales for supplies division", computeSales());
    }//end override
    
   
}
