/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Account Interface
*/
package accounts;


public interface Accounts_Interface {
    //constant double computeSales
    double computeSales();
}
