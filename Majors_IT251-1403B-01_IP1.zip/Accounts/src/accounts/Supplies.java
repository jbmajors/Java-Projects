/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Supplies SubClass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Supplies {
    
    //variables
    private double supplySold, supplyPrice;
    private int supplyAmount;

    //get and set the price of each supply item sold
    public double getSupplyPrice() {
        return supplyPrice;
    }

    public void setSupplyPrice(double supplyPrice) {
        this.supplyPrice = supplyPrice;
    }

    //get and set the amount of supplies sold
    public int getSupplyAmount() {
        return supplyAmount;
    }

    public void setSupplyAmount(int supplyAmount) {
        this.supplyAmount = supplyAmount;
    }

    //set and get the total cost of the supplies sold
    public double getSupplySold() {
        return supplySold;
    }

    public void setSupplySold(double supplySold) {
        this.supplySold = supplyPrice*supplyAmount;
    }
    
    
    
    
   
}
