/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Accounts Super Class
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Account {
    //Variables
    private String name, billingAddress, deliveryAddress, emailAddress, welcome;
    private int accountID;
    
    
    
    //Constructor Program Welcome
    //Program welcome
    public String getWelcome() {
        return welcome = "**Welcome to The Grind Office Supply System**";
    }
    
    
    //Constructor Get and Set Account ID
    public int getAccountID() {
        return accountID;
    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }
    
    //get and set name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    //get and set billing address    
    public String getBillingAddress() {
        return billingAddress;
    }
    
    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }

    //get and set delivery address
    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    //get and set email address
    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    
    
}
