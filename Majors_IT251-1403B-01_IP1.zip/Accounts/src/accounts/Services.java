/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Services SubClass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Services {
    
    //variables
    private int totalHours;
    private double ratePerHour, totalServiceCost;
    
    //get and set rate per hour for services
    public double getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(double ratePerHour) {
        this.ratePerHour = ratePerHour;
    }
    
    //get and set the total number of hours of services rendered
    public int getTotalHours() {
        return totalHours;
    }

    public void setTotalHours(int totalHours) {
        this.totalHours = totalHours;
    }
    
    //get and set the total cost of the services rendered
    public double getTotalServiceCost() {
        return totalServiceCost;
    }

    public void setTotalServiceCost(double totalServiceCost) {
        this.totalServiceCost = totalHours*ratePerHour;
    }
    
    
    
}
