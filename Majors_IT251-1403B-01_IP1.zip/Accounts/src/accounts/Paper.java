/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Paper Subclass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Paper {
    
    //variables
    private double pricePerLbs, totalPaperProfit;
    private int lbsPaperSold;

    //get and set the price per pound for paper
    public double getPricePerLbs() {
        return pricePerLbs;
    }

    public void setPricePerLbs(double pricePerLbs) {
        this.pricePerLbs = pricePerLbs;
    }

    //get and set the amount of paper sold in pounds
    public int getLbsPaperSold() {
        return lbsPaperSold;
    }

    public void setLbsPaperSold(int lbsPaperSold) {
        this.lbsPaperSold = lbsPaperSold;
    }

    //get and set the profit from paper sold
    public double getTotalPaperProfit() {
        return totalPaperProfit;
    }

    public void setTotalPaperProfit(double totalPaperProfit) {
        this.totalPaperProfit = pricePerLbs*lbsPaperSold;
    }
    
    
}
