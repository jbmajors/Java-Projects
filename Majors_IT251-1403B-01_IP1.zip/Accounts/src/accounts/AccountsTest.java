/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Accounts Test applicaiton
*/

package accounts;

//imports
import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class AccountsTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //variables
        String name, billingAddress, deliveryAddress, emailAddress, welcome;
        int accountID;
        
        // Instantiate Account Object
        Account myAccount = new Account();
        myAccount.getWelcome();
        System.out.println();
        
        //Initialize the Scanner for User Input
        Scanner input = new Scanner(System.in);
        
        //call method to set account id
        System.out.println("\nPlease enter the account ID: \n");
        accountID = input.nextInt();
        myAccount.setAccountID(accountID);
        
        //call method to display the account ID
        myAccount.getAccountID();
        System.out.println();
        System.out.println("\nThe account ID you entered is: "+accountID+"\n\n");
        
        //call method to set name
        System.out.println("\nPlease enter the account holder's name: \n");
        name = input.nextLine();
        myAccount.setName(name);
        
        //call method to display the account ID
        myAccount.getName();
        System.out.println();
        System.out.println("\nThe account holder name you entered is: "+name+"\n\n");
        
        //call method to set account holder billing address
        System.out.println("\nPlease enter the account holder's billing address: \n");
        billingAddress = input.nextLine();
        myAccount.setBillingAddress(billingAddress);
        
        //call method to display the account holder's address
        myAccount.getBillingAddress();
        System.out.println();
        System.out.println("\nThe account holder address you entered is: "+billingAddress+"\n\n");
        
        //call method to set account holder delivery address
        System.out.println("\nPlease enter the account delivery address: \n");
        deliveryAddress = input.nextLine();
        myAccount.setDeliveryAddress(deliveryAddress);
        
        //call method to display the account holder delivery address
        myAccount.getDeliveryAddress();
        System.out.println();
        System.out.println("\nThe account holder delivery address you entered is: "+deliveryAddress+"\n\n");
        
        //call method to set account holder's email address
        System.out.println("\nPlease enter the account holder's email address: \n");
        emailAddress = input.nextLine();
        myAccount.setEmailAddress(emailAddress);
        
        //call method to display the account holder's email address
        myAccount.getEmailAddress();
        System.out.println();
        System.out.println("\nThe account holder's email you entered is: "+emailAddress+"\n\n");
        
        
    }
    
}
