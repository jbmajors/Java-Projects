/*
 * IT110-1302A-04 Introduction to Java Programming
 * File name: WCCI_Phase3_IP
 * Created: 27 April 2013
 * Purpose: To create a customized welcome for Worldwide Chocolate and 
 * Coffee Imports
 */
package WCCI_Phase3_IP;

import javax.swing.*;

/**
 * Worldwide Chocolate and Coffee Imports (WCCI) Application
 *
 * @author Jeremy Majors
 */
public class WCCI_Phase3_IP {
    
    public static void main(String[] args) {
        // declare and initialize variables 
        String openingMsg, nameInputMsg, customerName, nameOutputMsg, returnInputMsg, customerReturn, returnOutputMsg, greetingOutputMsg, outputMsg;
        String openingMsg1, openingMsg2, openingMsg3, openingMsg4, openingMsg5, openingMsg6, openingMsg7, loginMsg, userid = null, pwMsg, password = null;
        String invalidEntry;

        //booleans
        boolean returnYes;
        returnYes = true;
        boolean returnNo;
        returnNo = true;
        boolean notYesOrNo;
        notYesOrNo = true;
        boolean validCustomer;
        boolean returnName;
        boolean returnInvalid;

        // display opening message and system introduction
        invalidEntry = "Invalid Entry! Please select y or n";
        openingMsg1 = "*** Welcome to Worldwide Chocolate and Coffee Imports Online Ordering System *** \n\n";
        openingMsg2 = "You are now able to order your chocolate and coffee through our online ";
        openingMsg3 = "order system. \n\n";
        openingMsg4 = "The types of chocolate you can order are: ";
        openingMsg5 = "Belgian, U.S., or Ecuadorian. \n\n";
        openingMsg6 = "The types of coffee you can order are: ";
        openingMsg7 = "Ecuadorian, Panamanian, and Colombian. \n\n";
        openingMsg = openingMsg1 + openingMsg2 + openingMsg3 + openingMsg4 + openingMsg5 + openingMsg6 + openingMsg7;

        JOptionPane.showMessageDialog(null, openingMsg);

        // determine if they are a new or returning customer
        returnInputMsg = "Are you a returning customer (Enter y or n)? ";
        customerReturn = JOptionPane.showInputDialog(returnInputMsg);

        returnYes = customerReturn.equalsIgnoreCase("y");
        returnNo = customerReturn.equalsIgnoreCase("n");
        notYesOrNo = (returnYes != customerReturn.equalsIgnoreCase("y")) && (returnNo != customerReturn.equalsIgnoreCase("n"));
        
        // initialize return flag
        
        int returnFlag = 0;

        if (returnYes) {
            returnFlag = 1;
        }
        if (returnNo) {
            returnFlag = 2;
        }
        if (notYesOrNo) {
            returnFlag = 3;
        }

        // determine if new customer or returning customer   
        switch (returnFlag) {
            case 1:
                loginMsg = "Please enter your Current username:";
                userid = JOptionPane.showInputDialog(null, loginMsg);
                pwMsg = "Please enter your Current password: ";
                password = JOptionPane.showInputDialog(null, pwMsg);
                break;
            case 2:
                loginMsg = "Please enter your New username:";
                userid = JOptionPane.showInputDialog(null, loginMsg);
                pwMsg = "Please enter your New password: ";
                password = JOptionPane.showInputDialog(null, pwMsg);
                break;
            case 3:
                JOptionPane.showMessageDialog(null, invalidEntry);
                loginMsg = "Please enter your New username:";
                userid = JOptionPane.showInputDialog(null, loginMsg);
                pwMsg = "Please enter your New password: ";
                password = JOptionPane.showInputDialog(null, pwMsg);
        } //end switch

        // get required customer name using dialog boxes    
        nameInputMsg = "Enter your name: ";
        customerName = JOptionPane.showInputDialog(nameInputMsg);

        // repeat until a name is entered or exit after 3 tries   
        for (int i = 1; i <= 3; i++) {
            validCustomer = customerName.isEmpty();
            if (validCustomer) {
                JOptionPane.showMessageDialog(null, invalidEntry);
                if (i == 3) {
                    System.exit(0);
                } else {
                    nameInputMsg = "Enter your name: ";
                    customerName = JOptionPane.showInputDialog(nameInputMsg);
                }
            } else {
                break;
            }
        }

        // build output strings 
        nameOutputMsg = "Welcome " + customerName + ".\n";
        returnOutputMsg = "Your login is: " + userid + "/" + password + ".\n"; 
        greetingOutputMsg = "Thank you for visiting Worldwide Chocolate and Coffee Imports!" + "\n";

        // create output string 
        outputMsg = nameOutputMsg + returnOutputMsg + greetingOutputMsg;

// display output message 
        JOptionPane.showMessageDialog(null, outputMsg);
        System.exit(0);
    }
}
