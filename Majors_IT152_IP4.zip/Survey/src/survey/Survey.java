/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey Class
*/

package survey;

import java.util.*;


public class Survey {
    
    //variables
    private String surveyTitle, question;
    private static int respondentID = 0;
    private int questionNmbr, ratingNmbr, total;
    private String [] questionArray = new String [10];
    private int [][] resultsArray = new int [10][10];    
    
    //constructor one
    public Survey() {
    surveyTitle = "The default survey title is: Customer Survey";//default survey title
    }

    //constructor two
    public void setSurveyTitle (String newSurveyTitle){
        surveyTitle = newSurveyTitle;//user input to change survey title
    }
    public String getSurveyTitle (){
        return surveyTitle;//output survey title
    }
    
    public void setRespondentID(int respondentID) {
        Survey.respondentID = respondentID;
    }

    //increment respondent ID by 1
    public int generateRespondentID() {
        respondentID++;
        return respondentID;
    }

    public void displayMessage() {
        System.out.print(surveyTitle);
    }
    
    public void logResponse(int newRespondentID, int newQuestionNmbr, int newRatingNmbr){
        questionNmbr = newQuestionNmbr - 1;
        newRespondentID = 1;
        respondentID = newRespondentID;
        ratingNmbr = newRatingNmbr;
        
        do {
            for (int questionNmbr = 0; questionNmbr < 10; questionNmbr++){
                Scanner input = new Scanner(System.in);
                System.out.println("\nPlease answer the survey questions with the following:");
                System.out.println("\tEnter 1 for Strongly Disagree");
                System.out.println("\tEnter 2 for Disagree");
                System.out.println("\tEnter 3 for Neither Agree or Disagree");
                System.out.println("\tEnter 4 for Agree");
                System.out.println("\tEnter 5 for Strongly Agree");

                System.out.println("\nEnter your response for question number: "+(questionNmbr + 1)+":"+(questionArray[questionNmbr]));
                resultsArray[questionNmbr][respondentID] = input.nextInt();
                System.out.println();
                respondentID++;
            }
        }
        while (respondentID < 10);
    }
    
    public void enterQuestions(){
        System.out.print("\nPlease enter ten questions for your survey:\n");
        for (questionNmbr = 0; questionNmbr < questionArray.length; questionNmbr++){
            Scanner input = new Scanner(System.in);
            System.out.println("\nEnter your question for number: "+(questionNmbr + 1));
            question = input.nextLine();
            questionArray[questionNmbr] = question;
        }
    }
    
    //Output survey results
    public void displaySurveyResults(){
        System.out.println("The title of the survey is "+surveyTitle+"\n");
        for (int a = 0; a < resultsArray.length; a++){
            System.out.printf("Question %d", a + 1);
            System.out.println();
            for (int b = 0; b < resultsArray.length; b++){
                System.out.printf("\t\t"+resultsArray[a][b]);
            }
            System.out.println("\t");
        }
    }
    
    //Output question stats for a user inputed question number
    public void displayQuestionStats(int newQuestionNmbr){
        questionNmbr = newQuestionNmbr;        
        System.out.printf("\nThe question statistics are: \n");
        
        System.out.println(resultsArray[respondentID][questionNmbr]);
        
        
        System.out.println("\n");
    }
    
    public int topRatedQuestion(){
        int topRating = resultsArray [0][0];
        
        for (int[] ratings : resultsArray){
            for (int highRating : ratings){
                if (highRating > topRating) {
                    highRating = topRating;
                }
            }
            for (int count = 0; count < resultsArray.length; count++){
                System.out.println("The highest rated question is: "+ratings[count]);
            }
        }
        return topRating;
        
    }
    
    public int lowestRatedQuestion (){
        int lowestRating = resultsArray[0][0];
        
        for (int[] ratings : resultsArray){
            for (int lowRating : ratings){
                if (lowRating > lowestRating) {
                    lowRating = lowestRating;
                }
            }
            for (int count = 0; count < resultsArray.length; count++){
                System.out.println("The lowest rated question is: "+ratings[count]);
            }
        }
        return lowestRating;
        
    }
    
    public void presentQuestion(int questionNmbr){
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter the question number you would like to view: \n");
        questionNmbr = input.nextInt();
        System.out.println("The question which corresponds to the number you entered is: ");
        System.out.println("\t"+(questionArray[questionNmbr]));
        System.out.println();
    }
    
    public void presentQuestion(int questionNmbr, int respondentID){
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter the Respondent ID: \n");
        respondentID = input.nextInt();
        System.out.print("Please enter the question number you like to view: \n");
        questionNmbr = input.nextInt();
        System.out.print("Respondent "+respondentID+", question response is: ");
        System.out.println(resultsArray[respondentID][questionNmbr]);
    }
}
    
