/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey_Test applicaiton
*/

package survey;

import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class Survey_Test {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        
        String surveyTitle;
        int questionNmbr = 0, newRespondentID = 0, newQuestionNmbr = 0, newRatingNmbr = 0;
        
        //Instantiate Survey Object and assign to mySurvey
        Survey mySurvey = new Survey();
        mySurvey.displayMessage();
        System.out.println();
        
        //set new survey title
        Scanner input = new Scanner(System.in);
        System.out.println();
        System.out.print("\nPlease enter a new Survey Title: \n");
        surveyTitle = input.nextLine();
        mySurvey.setSurveyTitle(surveyTitle);
        
        
        //get and display the new survey title
        mySurvey.getSurveyTitle();
        System.out.println();
        System.out.print("The new survey title is: "+surveyTitle+"\n\n");
        
        //enter questions into the question array
        System.out.println();
        mySurvey.enterQuestions();
        System.out.println();
        
        //answer survey questions
        System.out.println();
        System.out.print("Your Respondent ID is: "+mySurvey.generateRespondentID()+"\n");
        mySurvey.logResponse(newRespondentID, newQuestionNmbr, newRatingNmbr);
        System.out.println();
        
        //display survey results
        System.out.println();
        mySurvey.displaySurveyResults();
        System.out.println();
        
        //display survey stats
        System.out.println();
        mySurvey.displayQuestionStats(questionNmbr);
        System.out.println();
        
        //top rated question
        System.out.println();
        mySurvey.topRatedQuestion();
        System.out.println();
        
        //lowest rated question
        System.out.println();
        mySurvey.lowestRatedQuestion();
        System.out.println();
        
        //prompt for and display a specific question number
        System.out.println();
        mySurvey.presentQuestion(questionNmbr);
        System.out.println();
        
        //overload the previous method by prompting for respondent id and question number
        System.out.println();
        mySurvey.presentQuestion(questionNmbr, newRespondentID);
        System.out.println();
    }
        
}        
