/*
* IT151-1402A-01 Introduction to Java Programming 1
* File name: Majors_IT151
* Created: 21 April 2014
* Purpose: Predefined Class Application
*/

package tomatoseeds;

/**
 *
 * @author Jeremy Majors
 */
public class Shipping {
    
    int s = 5;
    int p = 2;
    int shipping(){
        return(s * p);
    }
    
    
    
}
