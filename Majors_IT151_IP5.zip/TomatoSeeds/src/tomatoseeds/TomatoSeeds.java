/*
* IT151-1402A-01 Introduction to Java Programming 1
* File name: Majors_IT151_IP2
* Created: 21 April 2014
* Purpose: Predefined Class
*/

package tomatoseeds;

/**
 * Revision 1.3, 5 May 2014
 * @author Jeremy Majors
 */
public class TomatoSeeds {

    //variable declarations
        String growerName;
        String tomatoSeedName1;
        String tomatoSeedName2;
        double tomatoSeedPrice1;
        double tomatoSeedPrice2;
        
    //constructor initiation
    public TomatoSeeds(String name) {
        growerName = name;
    }
           
    //set grower's name
    public void setGrowerName(String name){
        growerName = name;
    }
        
    //get grower's name
    public String getGrowerName(){
        return growerName;
    }
        
    //set tomato seed name1
    public void setTomatoSeedName1(String name){
        tomatoSeedName1 = name;
    }

    //get tomato seed name1
    public String getTomatoSeedName1() {
        return tomatoSeedName1;
    }
    
    //set tomato seed name2
    public void setTomatoSeedName2(String name){
        tomatoSeedName2 = name;
    }

    //get tomato seed name2
    public String getTomatoSeedName2() {
        return tomatoSeedName2;
    }
    
    //set tomato seed asking price1
    public void setTomatoSeedPrice1(double tomatoSeedPrice1) {
        this.tomatoSeedPrice1 = tomatoSeedPrice1;
    }
        
    //get tomato seed asking price1
    public double getTomatoSeedPrice1(){
        return tomatoSeedPrice1;
        
    }
    
    //set tomato seed asking price2
    public void setTomatoSeedPrice2(double tomatoSeedPrice2) {
        this.tomatoSeedPrice2 = tomatoSeedPrice2;
    }
        
    //get tomato seed asking price2
    public double getTomatoSeedPrice2(){
        return tomatoSeedPrice2;
        
    }
    
    public void displayMessage()
    {
    //Welcome Message
    System.out.printf("***     Welcome To     *** \n"); 
    }
       
}
