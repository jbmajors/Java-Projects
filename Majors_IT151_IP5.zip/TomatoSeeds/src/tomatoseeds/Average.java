/*
* IT151-1402A-01 Introduction to Java Programming 1
* File name: Majors_IT151
* Created: 21 April 2014
* Purpose: Predefined Class Application
*/

package tomatoseeds;

import tomatoseeds.TomatoSeeds.*;

/**
 *
 * @author Jeremy Majors
 */
public class Average {
    
    double a;

    public Average() {
        this.a = (double) ((TomatoSeeds.TomatoSeedsPrice2 + TomatoSeeds.TomatoSeedPrice1)/2);
    }
    
}
