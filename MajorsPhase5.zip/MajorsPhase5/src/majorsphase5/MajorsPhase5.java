/*
 * IT110-1302A-04 Introduction to Java Programming
 * File name: WCCI_Phase5_IP
 * Created: 10 May 2013
 * Purpose: To create a customized welcome for Worldwide Chocolate and 
 * Coffee Imports
 */
package majorsphase5;

/**
 * Worldwide Chocolate and Coffee Imports (WCCI) Application
 *
 * @author Jeremy Majors
 */
public class MajorsPhase5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
