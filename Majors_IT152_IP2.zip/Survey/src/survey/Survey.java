/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey Class
*/

package survey;

import java.util.*;


public class Survey {
    
    //variables
    private String surveyTitle;
    private static int respondentID = 0;
    private int surveyID, surveyQNumber;
    private String [] surveyQuestions;
    private int [][] surveyResponses;    
    
    //constructor one initialize the default survey title
        public Survey() {
        this.surveyTitle = "Customer Survey";
    }

    //constructor two initialize the user input survey title
        public Survey(String name) {
            surveyTitle = name;
    }
        
    //constructor to initialize the first array
        public Survey(String[] surveyQuestions){
            this.surveyQuestions = surveyQuestions;
        }
        
    //constructor to initialize the second array
        public Survey(int[][] surveyResponses){
            this.surveyResponses = surveyResponses;
        }

    //setters
    public void setSurveyTitle(String name) {
        surveyTitle = name;
    }
    
    public void setSurveyID(int surveyID) {
        this.surveyID = surveyID;
    }
    
    public void setRespondentID(int respondentID) {
        Survey.respondentID = respondentID;
    }

    //Getters
    public String getSurveyTitle() {
        return surveyTitle;
    }

    public int getSurveyID() {
        return surveyID;
    }
    
    

    //increment respondent ID by 1
    public int generateRespondentID(int respondentID) {
        return respondentID + 1;
    }

    public void displayMessage() {
        System.out.print(surveyTitle);
    }
    
    //Survey Array Code Section
    
    public void logResponse(int respondentID, int surveyQNumber, int surveyResponse){
        //I have no idea how to do this at all
    }
    
    //Output survey results
    public void displaySurveyResults(){
        System.out.println(surveyTitle+"\n");
        for (int[] a: surveyResponses){
            System.out.println(a);
            System.out.println();
        }
    }
    
    //Output question stats for a user inputed question number
    public void displayQuestionStats(){
        System.out.println("Please enter an question number to see the response: \n");
        
    }
}
    
    
    
