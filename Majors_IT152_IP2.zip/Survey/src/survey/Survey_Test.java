/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey_Test applicaiton
*/

package survey;

import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class Survey_Test {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        
        //variables
        String surveyTitle;
        int surveyID, respondentID = 0;
        
        
        
        //create scanner for input from user
        Scanner input = new Scanner(System.in);
        
        //Instantiate Survey Object and assign to mySurvey
        Survey mySurvey = new Survey();
        String [] surveyQuestions = new String[10];
        int [][] surveyResponses = new int [10][10];
        mySurvey.displayMessage();
        
        
        //set new survey title
        System.out.println();
        System.out.print("\nPlease enter a new Survey Title: \n");
        surveyTitle = input.nextLine(); 
        mySurvey.setSurveyTitle(surveyTitle);
        
        //get and display the new survey title
        mySurvey.getSurveyTitle();
        System.out.println();
        System.out.print("The new survey title is: "+surveyTitle+"\n\n");
        
        //set the survey ID
        System.out.print("Please enter a survey ID number: \n");
        surveyID = input.nextInt();
        mySurvey.setSurveyID(surveyID);
        
        //get and display the entered survey ID number
        mySurvey.getSurveyID();
        System.out.println();
        System.out.print("The Survey ID number you entered is: "+surveyID+"\n\n");
        
        //display respondent ID
        System.out.print("Your Respondent ID is: "+mySurvey.generateRespondentID(respondentID)+"\n\n");
        
        //enter questions into the question array
        System.out.println();
                
        for(int surveyQNumber = 0; surveyQNumber < 10; surveyQNumber++){

            System.out.print("Please enter a question for your survey: \n");
            surveyQuestions [surveyQNumber] = input.next();
            
        }
        //display the survey questions entered
        System.out.print("The questions you entered for your survey are: \n");
        
        for (String s: surveyQuestions){
            System.out.println(s);
        }
        
        //get survey question responses
        System.out.println();
        
        for (int surveyQNumber = 0; surveyQNumber < 10; surveyQNumber++){
            System.out.println("Please answer the questions above with a 1 for least to 5 for greatest:");
            surveyResponses[respondentID][surveyQNumber] = input.nextInt();
            System.out.println();
        }
        
        //display survey results
        System.out.println("The survey results for your answers are: \n");
        mySurvey.displaySurveyResults();
        
        //display question stats for a user input question number
        int surveyQNumber = 0;
        mySurvey.displayQuestionStats();
        surveyQNumber = input.nextInt();
        for (int[] i: surveyResponses){
            System.out.println(i);
        }
    }
        
}        
