/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Paper Subclass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Paper extends Account {
    
    //variables
    private double pricePerLbs, totalPaperProfit;
    private int lbsPaperSold;

    public Paper (String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID, int lbsPaperSold, double pricePerLbs, double totalPaperProfit) { 
        super(aNameCustomer, aBillingAddress, aDeliveryAddress, anEmailAddress, anAccountID);
        
    }

    public void setPricePerLbs(double aPricePerLbs) {
        this.pricePerLbs = aPricePerLbs;
    }

    public double getPricePerLbs() {
        return pricePerLbs;
    }

    public void setTotalPaperProfit(double totalPaperProfit) {
        this.totalPaperProfit = lbsPaperSold * pricePerLbs;
    }

    public double getTotalPaperProfit() {
        return totalPaperProfit;
    }

    public void setLbsPaperSold(int aLbsPaperSold) {
        this.lbsPaperSold = aLbsPaperSold;
    }

    public int getLbsPaperSold() {
        return lbsPaperSold;
    }
    
    //toString Override
    @Override
    public String toString(){
        String formatStr = "Price Per Pound of Paper: %s\n Pounds of Paper Sold: %s\n Total Paper Profits: %s\n\n";
        String paperStr = String.format(formatStr, this.getPricePerLbs(), this.getLbsPaperSold(), this.getTotalPaperProfit());
        return paperStr;
    }
    
    @Override
    public void computeSales(){
        System.out.println("The computed sales for the Paper Department is:"+totalPaperProfit+"\n");
    }
    
}
