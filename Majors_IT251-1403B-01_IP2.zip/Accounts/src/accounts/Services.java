/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Services SubClass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Services extends Account {
    
    //variables
    private int totalHours;
    private double ratePerHour, totalServiceCost;
    
    public Services (String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID, int totalHours, int ratePerHour, int totalServicCost) { 
        super(aNameCustomer, aBillingAddress, aDeliveryAddress, anEmailAddress, anAccountID);
    
    }

    public void setRatePerHour(double aRatePerHour) {
        this.ratePerHour = aRatePerHour;
    }

    public double getRatePerHour() {
        return ratePerHour;
    }

    public void setTotalHours(int aTotalHours) {
        this.totalHours = aTotalHours;
    }

    public int getTotalHours() {
        return totalHours;
    }

    public void setTotalServiceCost(double totalServiceCost) {
        this.totalServiceCost = totalHours * ratePerHour;
    }

    public double getTotalServiceCost() {
        return totalServiceCost;
    }
    
    //toString Override
    @Override
    public String toString(){
        String formatStr = "Total Service Hours: %s\n Rate Per Hour of Service: %s\n Total Service Cost: %s\n\n";
        String paperStr = String.format(formatStr, this.getTotalHours(), this.getRatePerHour(), this.getTotalServiceCost());
        return paperStr;
    }
    
    @Override
    public void computeSales(){
        System.out.println("The computed sales for the Service Department is:"+totalServiceCost+"\n");
    }
    
    
}
