/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Accounts Test applicaiton
*/

package accounts;

//imports
import java.util.*;

/**
 *
 * @author Jeremy Majors
 */
public class AccountsTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //variables
        String aNameCustomer = "", aBillingAddress = "", aDeliveryAddress = "", anEmailAddress = "", welcome;
        int anAccountID = 0;
        
        // Instantiate Account Object
        Account myAccount = new Account(aNameCustomer, aBillingAddress, aDeliveryAddress, anEmailAddress, anAccountID);
        myAccount.welcomeMsg();
        System.out.println();
        
        //Initialize the Scanner for User Input
        Scanner input = new Scanner(System.in);
        
        //call method to set account id
        System.out.println("\nPlease enter the Customer's Account ID: \n");
        anAccountID = input.nextInt();
        myAccount.setAccountID(anAccountID);
        
        //call method to display the account ID
        myAccount.getAccountID();
        System.out.println();
        System.out.println("\nThe Account ID you entered is: "+anAccountID+"\n\n");
        
        //call method to set name
        System.out.println("\nPlease enter the Customer's Name: \n");
        aNameCustomer = input.nextLine();
        myAccount.setNameCustomer(aNameCustomer);
        
         //call method to display the account holder's name
        myAccount.getNameCustomer();
        System.out.println();
        System.out.println("\nThe account holder name you entered is: "+aNameCustomer+"\n\n");
        
        //call method to set account holder's billing address
        System.out.println("\nPlease enter the account holder's billing address: \n");
        aBillingAddress = input.nextLine();
        myAccount.setBillingAddress(aBillingAddress);
        
        //call method to display the account holder's address
        myAccount.getBillingAddress();
        System.out.println();
        System.out.println("\nThe account holder address you entered is: "+aBillingAddress+"\n\n");
        
        //call method to set account holder delivery address
        System.out.println("\nPlease enter the account delivery address: \n");
        aDeliveryAddress = input.nextLine();
        myAccount.setDeliveryAddress(aDeliveryAddress);
        
        //call method to display the account holder delivery address
        myAccount.getDeliveryAddress();
        System.out.println();
        System.out.println("\nThe account holder delivery address you entered is: "+aDeliveryAddress+"\n\n");
        
        //call method to set account holder's email address
        System.out.println("\nPlease enter the account holder's email address: \n");
        anEmailAddress = input.nextLine();
        myAccount.setEmailAddress(anEmailAddress);
        
        //call method to display the account holder's email address
        myAccount.getEmailAddress();
        System.out.println();
        System.out.println("\nThe account holder's email you entered is: "+anEmailAddress+"\n\n");
        
        
    }
    
}
