/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Accounts Super Class
*/

package accounts;

import java.util.*;
/**
 *
 * @author Jeremy Majors
 */
public class Account {
    //Variables
    private String nameCustomer, billingAddress, deliveryAddress, emailAddress, welcome;
    private int accountID, computeSales, nothing;
    
    //constructor
    public Account (String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID) { 
        
        nameCustomer = aNameCustomer;
        billingAddress = aBillingAddress;
        deliveryAddress = aDeliveryAddress;
        emailAddress = anEmailAddress;
        accountID = anAccountID;
        
                
    }

    //public methods
    
    //set the Account ID
    public void setAccountID(int anAccountID) {
        this.accountID = anAccountID;
    }

    //get the Account ID
    public int getAccountID() {
        return accountID;
    }

    //set the Customer Name
    public void setNameCustomer(String aNameCustomer) {
        this.nameCustomer = aNameCustomer;
    }

    //get the Customer Name
    public String getNameCustomer() {
        return nameCustomer;
    }
    
    //set the Customer's Billing Address
    public void setBillingAddress(String aBillingAddress) {
        this.billingAddress = aBillingAddress;
    }

    //get the Customer's Billing Address
    public String getBillingAddress() {
        return billingAddress;
    }

    //set the Customer's Delivery Address
    public void setDeliveryAddress(String aDeliveryAddress) {
        this.deliveryAddress = aDeliveryAddress;
    }

    //get the Customer's Delivery Address
    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    //set the Customer's Email Address
    public void setEmailAddress(String anEmailAddress) {
        this.emailAddress = anEmailAddress;
    }

    //get the Customer's Email Address
    public String getEmailAddress() {
        return emailAddress;
    }
    
    //Program welcome
    public void welcomeMsg() {
        welcome = "**Welcome to The Grind Office Supply System**";
        System.out.println(welcome);
    }
    
    //toString Override
    @Override
    public String toString(){
        String formatStr = "Account ID: %s\n Customer Name: %s\n Billing Address: %s\n Delivery Address: %s\n Email Address: %s\n\n";
        String accountStr = String.format(formatStr, this.getAccountID(), this.getNameCustomer(), this.getDeliveryAddress(), this.getDeliveryAddress(), this.getEmailAddress());
        return accountStr;
    }
    
    public void computeSales(){
        nothing = 0;
    }
    
    
}
