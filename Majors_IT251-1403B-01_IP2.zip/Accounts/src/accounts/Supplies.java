/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Supplies SubClass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Supplies extends Account {
    
    //variables
    private double supplySold, supplyPrice, booksPrice, booksSold, apparelPrice, apparelSold;
    private int supplyAmount, booksAmount, apparelAmount;

    
    public Supplies (String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID, int supplyAmount, int booksAmount, int apparelAmount, double booksSold, double booksPrice, double apparelPrice, double apparelSold, double supplySold, double supplyPrice) { 
        super(aNameCustomer, aBillingAddress, aDeliveryAddress, anEmailAddress, anAccountID);
    
    }

    public void setSupplyAmount(int aSupplyAmount) {
        this.supplyAmount = aSupplyAmount;
    }

    public int getSupplyAmount() {
        return supplyAmount;
    }

    public void setSupplyPrice(double aSupplyPrice) {
        this.supplyPrice = aSupplyPrice;
    }

    public double getSupplyPrice() {
        return supplyPrice;
    }

    public void setSupplySold(double aSupplySold) {
        this.supplySold = aSupplySold;
    }

    public double getSupplySold() {
        return supplySold;
    }

    public void setBooksPrice(double abooksPrice) {
        this.booksPrice = abooksPrice;
    }

    public double getBooksPrice() {
        return booksPrice;
    }

    public void setBooksAmount(int abooksAmount) {
        this.booksAmount = abooksAmount;
    }

    public int getBooksAmount() {
        return booksAmount;
    }

    public void setBooksSold(double booksSold) {
        this.booksSold = booksPrice * booksAmount;
    }

    public double getBooksSold() {
        return booksSold;
    }

    public void setApparelPrice(double anApparelPrice) {
        this.apparelPrice = anApparelPrice;
    }

    public double getApparelPrice() {
        return apparelPrice;
    }

    public void setApparelAmount(int anApparelAmount) {
        this.apparelAmount = anApparelAmount;
    }

    public int getApparelAmount() {
        return apparelAmount;
    }

    public void setApparelSold(double apparelSold) {
        this.apparelSold = apparelAmount * apparelPrice;
    }

    public double getApparelSold() {
        return apparelSold;
    }
    
    //toString Override
    @Override
    public String toString(){
        String formatStr = "Amount of Supplies: %s\n Price of Supplies: %s\n Total Supplies Sold: %s\n\n";
        String paperStr = String.format(formatStr, this.getSupplyAmount(), this.getSupplyPrice(), this.getSupplySold());
        return paperStr;
    }
    
    @Override
    public void computeSales(){
        double total = supplySold + booksSold + apparelSold;
        System.out.println("The total sales for the Supplies Department is: "+total+"\n");
    }
    
    
   
}
