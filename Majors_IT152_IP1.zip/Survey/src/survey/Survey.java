/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey Class
*/

package survey;


public class Survey {
    
    //variables
    private String surveyTitle;
    private static int respondentID = 0;
    private int surveyID;
    
    
    //constructor one
    public Survey() {
        this.surveyTitle = "Customer Survey";
    }

    //constructor two
    public Survey(String name) {
        surveyTitle = name;
    }

    //setters
    public void setSurveyTitle(String name) {
        this.surveyTitle = name;
    }
    
    public void setSurveyID(int surveyID) {
        this.surveyID = surveyID;
    }
    
    public void setRespondentID(int respondentID) {
        Survey.respondentID = respondentID;
    }
    

    //Getters
    public String getSurveyTitle() {
        return surveyTitle;
    }

    public int getSurveyID() {
        return surveyID;
    }
        
    //increment respondent ID by 1
    public int generateRespondentID(int respondentID) {
        return respondentID + 1;
    }

    public void displayMessage() {
        System.out.print(surveyTitle);
    }
}
