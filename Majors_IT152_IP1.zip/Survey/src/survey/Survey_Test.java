/*
* IT151-1402B-01 Introduction to Java Programming 2
* File name: Surveys
* Created: 27 April 2014
* Purpose: Creation of Survey_Test applicaiton
*/

package survey;

import java.util.*;

public class Survey_Test {

    public static void main(String[] args) {
        
        //variables
        String surveyTitle;
        int surveyID, respondentID = 0;
        
        //create scanner for input from user
        Scanner input = new Scanner(System.in);
        
        //Instantiate Survey Object and assign to mySurvey
        Survey mySurvey = new Survey();
        mySurvey.displayMessage();
        
        
        //set new survey title
        System.out.println();
        System.out.print("\nPlease enter a new Survey Title: \n");
        surveyTitle = input.nextLine(); 
        mySurvey.setSurveyTitle(surveyTitle);
        
        //get and display the new survey title
        mySurvey.getSurveyTitle();
        System.out.println();
        System.out.print("The new survey title is: "+surveyTitle+"\n\n");
        
        //set the survey ID
        System.out.print("Please enter a survey ID number: \n");
        surveyID = input.nextInt();
        mySurvey.setSurveyID(surveyID);
        
        //get and display the entered survey ID number
        mySurvey.getSurveyID();
        System.out.println();
        System.out.print("The Survey ID number you entered is: "+surveyID+"\n\n");
        
        //display respondent ID
        System.out.print("Your Respondent ID is: "+mySurvey.generateRespondentID(respondentID)+"\n\n");
    }
}
