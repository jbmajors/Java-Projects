/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Services SubClass
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */
public class Services extends Accounts {
    
    //variables
    private double totalHours;
    private double ratePerHour;
    
    //Constructor with arguments
    public Services(String aNameCustomer, String aBillingAddress, String aDeliveryAddress, String anEmailAddress, int anAccountID,
            double totHours, double ratePerHr){
        super(aNameCustomer, aBillingAddress, aDeliveryAddress, anEmailAddress, anAccountID);
        totalHours=totHours;
        ratePerHour=ratePerHr;
    }

    //set the dollar amount charged per hour
    public void setRatePerHour(double ratePerHr) {
        this.ratePerHour = ratePerHr;
    }//end set method

    //get the dollar amount charged per hour
    public double getRatePerHour() {
        return ratePerHour;
    }//end get method

    //set the total number of hours charged
    public void setTotalHours(double totHours) {
        this.totalHours = totHours;
    }//end set method

    //get the total number of hours charged
    public double getTotalHours() {
        return totalHours;
    }//end get method
    
    //Override computeSales method in super class 
    @Override
    public double computeSales(){
        return (ratePerHour * totalHours);
    }//end override
    
    //Override toString method in super class
    @Override
    public String toString(){
        
        //return string with arguments
        return String.format( "\n%s \n%s \n%s %s \n%s $%s \n%s $%s", 
            "Services account information: ", super.toString(), 
            "Number of hours worked: ", getTotalHours(),
            "Dollar rate per hour: ", getRatePerHour(),
            "Total sales for services division: ", computeSales());
    }//end override
    
}//end services class
