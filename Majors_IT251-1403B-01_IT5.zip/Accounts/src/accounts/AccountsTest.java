/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 25 August 2014
* Purpose: Creation of Accounts Test applicaiton
*/

package accounts;

//imports
import java.util.Scanner;
import javax.swing.JFrame;

/**
 *
 * @author Jeremy Majors
 */
public class AccountsTest {

    //set variables
    static double supplies;
    static double books;
    static double apparel;
    static double totalHrs;
    static double serviceRPH;
    static double numLbs;
    static double pricePerLbs;
    static double totaler;
    static double papers;
    static double service;
    static double supply;
    static int menu;
    static int item = 0;
    static int max = 3;
    static int data = 0;
    
    public static void main(String[] args) throws InterruptedException{
        
        //Array Accounts named salesAccounts set for 3 entries only
        Accounts[] salesAccounts = new Accounts[max];

        //Program Welcome
        System.out.println("Welcome to The Grind Office Supply Accounts System!!\n");
        System.out.println("All entries into the account system must be done one at a time:\n");

        //begin first do loop
        do {
            //Start innermost do loop
            do {
                //initialize menuScanner
                Scanner menuScanner = new Scanner(System.in);

                //Prompt user for menu choice of Paper, Supplies, or Services
                System.out.println("\nPlease choose an account:\n");
                System.out.println("1. Paper \n");
                System.out.println("2. Supplies \n");
                System.out.println("3. Services ");
                System.out.println("___________________________\n");

                //Get the users selection 
                menu = menuScanner.nextInt();

            //while conditions
            } while ( ( menu < 1 ) || ( menu > 4 ) ); 

            //switch for cases from user menu selection
            switch ( menu ) {

                //Case for user selection of 1
                case 1:

                    //initialize scanner for total pounds of paper sold
                    Scanner numberLbsScanner = new Scanner(System.in);

                    //prompt user for total number of pounds of paper sold
                    System.out.println("\nEnter total number of pounds of paper sold: ");

                    //variable numbLbs value assignment
                    numLbs = numberLbsScanner.nextDouble();

                    //initialize scanner for price per pound of paper
                    Scanner pricePerLbsScanner = new Scanner(System.in);

                    //prompt for input
                    System.out.println("Enter price per pound sold: ");
                    //assign input to variable perPoundPrice
                    pricePerLbs = pricePerLbsScanner.nextDouble();

                    //Accounts sales array 1
                    salesAccounts[data] = new Paper("Kinkos", "7869 Copy Way, California 94583", "7869 Copy Way, California 94583",
                    "copynerds@kinkos.com", data + 1, numLbs, pricePerLbs);

                break; //end case 1

                //Case for user selection of 2
                case 2: 

                    //initialize supply scanner
                    Scanner supplyScanner = new Scanner(System.in);

                    //prompt user for total dollar amount of office supplies sold
                    System.out.println("Enter total dollar amount of office supplies sold: ");

                    //variable supplies value assignment
                    supplies = supplyScanner.nextDouble();

                    //initialize book scanner
                    Scanner bookScanner = new Scanner(System.in);

                    //prompt user for total dollar amount of books sold
                    System.out.println("Enter total dollar amount of books sold: ");

                    //variable books value assignment
                    books = bookScanner.nextDouble();

                    //initialize apparel items scanner
                    Scanner apparelScanner = new Scanner(System.in);

                    //prompt for total dollar amount of apparel items sold 
                    System.out.println("Enter total dollar amount of apparel items sold: ");

                    //variable apparel value assignment
                    apparel = apparelScanner.nextDouble();

                    //Accounts sales array 2
                    salesAccounts[data] = new Supplies("Arduous Adventures", "911 Rapid St, California 94583", "925 Rapid St, California 94583",
                    "whitewater@getsome.com", data + 1, supplies, books, apparel);

                break;//end Case 2

                //Case for user selection of 3
                case 3:

                    //initialize service hours scanner
                    Scanner serviceHrsScanner = new Scanner(System.in);

                    //prompt user for total number of service hours
                    System.out.println("\nEnter total number of services hours: ");

                    //variable service hours value assignment
                    totalHrs = serviceHrsScanner.nextDouble();

                    //initialize service rate per hour scanner   
                    Scanner serviceRPHScanner = new Scanner(System.in);

                    //prompt user for the dollar amount charged per hour
                    System.out.println("Enter the total dollar amount charged per hour: ");

                    //variable service rate per hour value assignment
                    serviceRPH = serviceRPHScanner.nextDouble();

                    //Accounts sales array 3
                    salesAccounts[data] = new Services("River City", "411 Main St, California 94583", "411 Main St, California 94583",
                    "stealingyourcash@crooks.com", data + 1, totalHrs, serviceRPH);

                break;//end Case 3

                //Default Case 
                default:

                    //processing sales message
                    System.out.println("Processing sales...");

                    //variable item value assignment
                    item = 0;

                    //begin for loop and set arguments
                    for ( Accounts currentAccount : salesAccounts ) {

                        //Set if argument null statement
                        if (currentAccount != null) {

                            //output item number
                            System.out.println("Item #"+item);

                            //output currentAccount array
                            System.out.println(currentAccount);

                            //Call computeSales method
                            currentAccount.computeSales();

                            //Increment item number 
                            item += 1;

                        }//end if

                    }//end for

                break;//end Default Case

            }//end switch

            //begin if loop for data sequence two
            if (data == 2){

                //display max entries message
                System.out.println("\n\n\nMaximum entries reached.");

                //display processing sales message
                System.out.println("\nProcessing sales...");

                //variable item value assignment
                item = 0;

                //begin for loop and set arguments
                for ( Accounts currentAccount : salesAccounts ) {

                    //begin if loop and set null state
                    if (currentAccount != null) {

                        //Display item number
                        System.out.println("Item #"+item);

                        //display account information
                        System.out.println(currentAccount);

                        //Call computeSales method
                        currentAccount.computeSales();
                        item += 1;

                    }//end if

                }//end for

            }//end if

        //increment data
        data += 1;

        //begin while and set arguments
        } while ( menu != 4 && data < max );
        
        double aggSales = 0;

        // process sales objects through polymorphical calls
        for ( Accounts currentAccount : salesAccounts ) {
            if (currentAccount != null)
            {
                aggSales += currentAccount.computeSales();
            }
        }
        System.out.println("\n\n");
        System.out.println("The Grind Office Supply Accounts");
        System.out.println("Total sales YTD are: $" + String.valueOf(aggSales));
        
        //creates frame 
        JFrame frame = new JFrame("The Grind Office Supply Account System");
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
 
        //a sentinal value to allow loop to function
        int x = 0;
        
        //instantiates the neon sign and sets the size 
        Signage mysign = new Signage();
        frame.add( mysign );
        frame.setSize( 800, 520 );
        
        //loop to make neon sign go on and off
        while (x == 0){
            
            //neon sign on
            frame.setVisible( true );
        
            //neon sign is on for 1.5 seconds
            Thread.sleep(1500);
        
            //neon sign off
            frame.setVisible( false );
            
            //neon sign is off for one second
            Thread.sleep(1000);
        }
            

    }//end main

}//end test program
