/*
* IT251-1403B-01 Intermediate Java Programming 1
* File name: Accounts
* Created: 22 September 2014
* Purpose: Creation of Graphic Sign
*/

package accounts;

/**
 *
 * @author Jeremy Majors
 */

//imports
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import javax.swing.JPanel;

public class Signage extends JPanel{
    
    //overrides and displays graphics 
    @Override
    public void paintComponent ( Graphics g ){
     
        //call to superclass paintComponent
        super.paintComponent( g );
        
        //cast g to Graphics2D
        Graphics2D g2d = ( Graphics2D ) g;
        
        //sets background color
        this.setBackground( Color.black );
       
        //draw rectangle and fill with yellow
        g.setColor( new Color( 255, 255, 0) );
        g.fillRect( 49, 15, 670, 450 );
        
        //draw 2D ellipse and allow color to change from red to orange
        g2d.setPaint( new GradientPaint( 150, 15, Color.RED, 460, 450, Color.ORANGE, true));
        g2d.fill( new Ellipse2D.Double( 150, 15, 460, 450) );
        
        //draw string and set font,type, size, color and location
        g.setFont( new Font( "SanSerif", Font.BOLD, 35) );
        g.setColor(Color.BLUE);
        g.drawString( "The Grind Office Supply Account System", 50, 250 );
    }
    
}
